<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo e($user->image ? $user->image:'https://picsum.photos/50/50'); ?>" width="85" class="rounded-circle justify-content-end">
                        <?php if($user->id==\Auth::user()->id): ?>
                        <form action="<?php echo e(url('/profile')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mt-3">
                                <input type="file" class="form-control-file" name="image">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Upload</button>
                            </div>
                        </form>
                        <?php endif; ?>
                        <div class="h5 mt-3"><?php echo e($user->name); ?></div>
                        <?php if($user->id!=\Auth::user()->id): ?>
                                <form action="<?php echo e(url('/follow/'.$user->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group mt-3">
                                        <?php if(!$friend): ?>
                                            <button type="submit" class="btn btn-info">Follow</button>
                                        <?php else: ?>
                                            <button type="submit" class="btn btn-info">Unfollow</button>
                                        <?php endif; ?>
                                    </div>
                                </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <?php if($user->id==\Auth::user()->id): ?>
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(url('/post')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <textarea class="form-control" name="body" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <input type="file" class="form-control-file" name="image">
                            </div>
                            <div class="btn-toolbar justify-content-end">
                                <div class="btn-group">
                                    <button class="btn btn-outline-primary" type="submit">Post</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(!empty($posts)): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mt-3">
                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="mr-2">
                                            <a href="<?php echo e(url('/profile/'.$post->user->id)); ?>">
                                                <img src="<?php echo e($user->image ? $user->image:'https://picsum.photos/50/50'); ?>" width="45" class="rounded-circle">
                                            </a>
                                        </div>
                                        <div class="ml-2">
                                            <div class="h5 m-0"><?php echo e($post->user->name); ?></div>
                                            <div class="text-muted">
                                                <i class="fa fa-clock-o"></i> <?php echo e($post->created_at->diffForhumans()); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="card-text">
                                    <?php echo e($post -> body); ?>

                                </div>
                                <p class="text-center">
                                    <img src="<?php echo e($post->image); ?>" class="img-fluid">
                                </p>
                                <div class="d-flex justify-content-between">
                                    <div class="d-flex justify-content-between">
                                        <form action="<?php echo e(url('/post/like/'.$post->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php if(!$post->likes->contains('user_id',\Auth::user()->id)): ?>
                                                <button class="btn btn-outline-primary" type="submit"><i class="far fa-thumbs-up"></i> Like</button>
                                            <?php else: ?>
                                                <button class="btn btn-primary" type="submit"><i class="far fa-thumbs-up"></i> Like</button>
                                            <?php endif; ?>
                                        </form>
                                        <span class="text-muted">&nbsp; <?php echo e($post->likes->count()); ?></span>
                                    </div>
                                    <div>
                                        <span class="text-muted">comments <?php echo e($post->comments->count()); ?></span>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <form action="<?php echo e(url('/post/comment/'.$post->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <textarea name="body" rows="3" class="form-control"></textarea>
                                        </div>
                                        <div class="btn-toolbar justify-content-end">
                                            <div class="btn-group">
                                                <button type="submit" class="btn btn-primary">Comment</button>
                                            </div>
                                        </div>
                                    </form>
                                    <?php if(!$post->comments->isEmpty()): ?>
                                        <ul class="list-unstyled mt-3">
                                            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="media p-2 mt-2">
                                                    <a href="<?php echo e(url('/profile/'.$comment->user->id)); ?>">
                                                        <img src="<?php echo e($comment->user->image ? $comment->user->image:'https://picsum.photos/50/50'); ?>" class="rounded-circle mr-3" width="30">
                                                    </a>
                                                    <div class="media-body">
                                                        <div class="h6 m-8"><?php echo e($comment->user->name); ?></div>
                                                        <?php echo e($comment->body); ?>

                                                        <div class="text-muted">
                                                            <i class="fa fa-clock-o"></i> <?php echo e($comment->created_at->diffForhumans()); ?>

                                                        </div>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\social\resources\views/profile.blade.php ENDPATH**/ ?>